const { validate } = require('./request-validator');

describe('Request Validator', () => {
    it('should validate a correct request', () => {
        const validRequest = {
            email: 'user@example.com',
            audio: 'audioBlobData'
        };
        const isValid = validate(validRequest);
        expect(isValid).toBe(true);
    });

    it('should invalidate a request with missing email', () => {
        const invalidRequest = {
            audio: 'audioBlobData'
        };
        const isValid = validate(invalidRequest);
        expect(isValid).toBe(false);
    });

    it('should invalidate a request with invalid email format', () => {
        const invalidRequest = {
            email: 'invalid-email',
            audio: 'audioBlobData'}

        const isValid = validate(invalidRequest);
        expect(isValid).toBe(false);
    });

    it('should invalidate a request with missing audio', () => {
        const invalidRequest = {
            email: 'user@example.com'
        };
        const isValid = validate(invalidRequest);
        expect(isValid).toBe(false);
    });
});