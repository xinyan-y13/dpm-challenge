const Ajv = require('ajv');
const addFormats = require('ajv-formats');

const ajv = new Ajv();
addFormats(ajv, ['email']);

// I want to validate all arguments because USER CANNOT BE TRUSTED
const uploadSchema = {
    type: 'object',
    properties: {
        email: { type: 'string', format: 'email' },
    },
    required: ['email'],
    additionalProperties: true
};

const validateUploadSchema = ajv.compile(uploadSchema);

module.exports = { validateUploadSchema }