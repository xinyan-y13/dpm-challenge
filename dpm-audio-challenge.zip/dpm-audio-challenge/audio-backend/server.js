const express = require('express');
const cors = require('cors');
const { validateUploadSchema } = require('./request-validator');
const multer  = require('multer')
const upload = multer({ dest: 'uploads/' })

const app = express();
const router = express.Router();
const port = 3001;

app.use(cors());
app.use('/', router);
app.use(express.json())

const validateRequest = (req, res, next) => {
    const valid = validateUploadSchema(req.body);
    if (!valid) {
        if (!valid) {
            const error = new Error('Validation failed');
            error.status = 400;
            error.errors = validateUploadSchema.errors;
            return next(error);
        }
    }
    next();
};

// probably a healthcheck call to backend would be nice since the frontend wants to know if backend is still alive.
// in real life this doesn't have to be done by frontend.
router.get('/healthcheck', (req, res) => {
    res.send('I am alive!');
});

router.post('/record/upload', upload.fields([{ name: 'audio', maxCount: 1 }, { name: 'email', maxCount: 1 }]), validateRequest,  async (req, res) => {
    setTimeout(() => {
        // I seriously don't know anything about audio processing in backend, so I'll leave this empty
        // Just imagine something magic happens here :D
        res.status(200).json({
            isSuccessful: true
        })
    }, 3000); // let's say the normal processing will take 2 seconds.

});

app.listen(port, () => {
    console.info(`Listening http://localhost:${port}`);
});
