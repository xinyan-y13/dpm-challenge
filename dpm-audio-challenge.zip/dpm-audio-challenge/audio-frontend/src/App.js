import React, { useCallback, useEffect, useRef, useState } from 'react';
import { FaMicrophone } from 'react-icons/fa';

function App() {
    const [_, setHealthCheckMessage] = useState('');
    const [errorMessage, setErrorMessage] = useState(null);
    const [audioURL, setAudioURL] = useState('');
    const [audioBlobs, setAudioBlobs] = useState([]);
    const [isRecording, setIsRecording] = useState(false);
    const [isUploading, setIsUploading] = useState(false);

    const mediaRecorderRef = useRef(null);

    const handleOnSubmit = useCallback(async (event) => {
        event.preventDefault();
        setIsUploading(true);
        setErrorMessage(null);

        if (!audioBlobs) {
            setErrorMessage('Please record an audio before submitting.');
        }

        try {
            const formData = new FormData(event.target);
            formData.append('audio', audioBlobs, 'recording.wav');
            const response = await fetch('http://localhost:3001/record/upload', {
                method: 'POST',
                body: formData,
            });

            // this should be the result of processed audio
            // to be set and displayed on screen.
            const result = await response.json();
        } catch (e) {
            setErrorMessage(`Error occurred while transmitting the audio or processing it. ${e}`);
        } finally {
            setIsUploading(false);
        }

    }, [audioBlobs]);

    /*
    * To be honest, I haven't dealt with audio recording before, so the following lines mostly come from the following source:
    * https://franzeus.medium.com/record-audio-in-js-and-upload-as-wav-or-mp3-file-to-your-backend-1a2f35dea7e8
    */
    const onClickAudioRecording = async () => {
        if (!isRecording) {
            const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
            mediaRecorderRef.current = new MediaRecorder(stream);
            mediaRecorderRef.current.addEventListener('dataavailable', (event) => {
                audioBlobs.push(event.data);
            });
            mediaRecorderRef.current.start();
            setIsRecording(true);
        } else {
            mediaRecorderRef.current.stop();
            mediaRecorderRef.current.addEventListener('stop', () => {
                const audio = new Blob(audioBlobs, { type: 'audio/wav' });
                setAudioBlobs(audio);
                const audioURL = URL.createObjectURL(audio);
                setAudioURL(audioURL);
            });

            setIsRecording(false);
        }
    }

    useEffect(() => {
        const fetchData = async () => {
            try {
                const response = await fetch('http://localhost:3001/healthcheck');
                const data = await response.text();
                setHealthCheckMessage(data);
            } catch (error) {
                setHealthCheckMessage(null)
                setErrorMessage(error.message);
            }
        };

        fetchData();

        // i want to constantly call healthcheck to see if backend is still alive.
        const intervalId = setInterval(fetchData, 60000);
        // cleanup on unmount
        return () => clearInterval(intervalId);
    }, []);


    return (
        <div className="Recording-Page">
            <h1>Record your audio!</h1>
            <form className="Recording-form" onSubmit={handleOnSubmit} encType="multipart/form-data">
                <div className="Recording-form-row">
                    <FaMicrophone className="Recording" onClick={onClickAudioRecording}/>
                    Please press on the button to record
                </div>
                {isRecording && <div className="Recording-status">Recording...</div>}

                <div className="Recording-form-row">
                    <input className="Recording-form-email" type="email" name="email" placeholder="Email" required />
                    <button type="submit" disabled={isUploading}>Submit</button>
                </div>

            </form>

            {errorMessage && <div className="Recording-error-essage">{errorMessage}</div>}
            {audioURL && <audio src={audioURL} controls />}

        </div>
    );
}

export default App;
